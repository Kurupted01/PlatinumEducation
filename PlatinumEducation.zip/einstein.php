<!DOCTYPE html>
<html>

    <head> <link rel="icon" type="image/x-icon" href="images/Favicon.png"/>
    <title>Maths Tutoring Sydney - Platinum Education Australia | 100% Tutor Support in Sydney for HSC, IB &amp; University Maths| 100% Support Chemistry Maths Physics Biology English</title>
        <meta http-equiv="Content-Type" content="text/html; charset=iso-8859-1" />
        <meta name="description" CONTENT="Experienced and Dedicated tutoring to maximise your UAI. We are the specialists in chemistry, maths, physics, english and biology tutoring. Complete year 11 and year 12 course" />
        <meta name="keywords" CONTENT="einsteins challenge, tutoring, tutor, maths, english, Sydney, local, Private, chemistry, biology, Coaching,, physics, general ability, reading, writing, home, hsc, IB, teaching" />
        <meta name="Robots" content="index, follow" />
        <link rel="stylesheet" type="text/css" href="css/bootstrap.css" />
        <link rel="stylesheet" type="text/css" href="style.css">
        <link rel="stylesheet" type="text/css" href="css/customStyles.css" />
        <link rel="stylesheet" type="text/css" href="css/custom/einstein-page.css" />
        <link rel="stylesheet" type="text/css" href="css/bootstrapValidator.min.css"/>

    <script type="text/javascript">
<!--
function MM_goToURL() { //v3.0
  var i, args=MM_goToURL.arguments; document.MM_returnValue = false;
  for (i=0; i<(args.length-1); i+=2) eval(args[i]+".location='"+args[i+1]+"'");
}
//-->
    </script>
	<script type="text/javascript">

  var _gaq = _gaq || [];
  _gaq.push(['_setAccount', 'UA-32906721-1']);
  _gaq.push(['_trackPageview']);

  (function() {
    var ga = document.createElement('script'); ga.type = 'text/javascript'; ga.async = true;
    ga.src = ('https:' == document.location.protocol ? 'https://ssl' : 'http://www') + '.google-analytics.com/ga.js';
    var s = document.getElementsByTagName('script')[0]; s.parentNode.insertBefore(ga, s);
  })();

</script>
</head>

<body leftmargin=0 topmargin=0 marginheight="0" marginwidth="0" bgcolor="#ffffff">

<script language=JavaScript>

<!--
var message="";

///////////////////////////////////

function clickIE() {if (document.all) {(message);return false;}}

function clickNS(e) {if 

(document.layers||(document.getElementById&&!document.all)) {

if (e.which==2||e.which==3) {(message);return false;}}}

if (document.layers) 

{document.captureEvents(Event.MOUSEDOWN);document.onmousedown=clickNS;}

else{document.onmouseup=clickNS;document.oncontextmenu=clickIE;}



document.oncontextmenu=new Function("return false")

// --> 

</script>



<table border="0" cellspacing="0" cellpadding="0" width="100%" height="100%">

<tr valign="top">

	<td width="50%" background="images/bg.gif"><img src="images/px1.gif" width="1" height="1" alt="" border="0"></td>

	<td valign="bottom" background="images/bg_left.gif"><img src="images/bg_left.gif" alt="" width="17" height="16" border="0"></td>

	<td>

<table border="0" cellpadding="0" cellspacing="0" width="780" height="219">

<tr valign="bottom">

	<td width="800" background="images/fon_top.gif"><table width="784" height="224" border="0" cellpadding="0" cellspacing="0" background="">

      <tr valign="bottom">

        <td width="237" rowspan="2"><img src="images/platedimage6.gif" width="181" height="219"> </td>

        <td height="163" colspan="6">
            <?php
                include 'partial/contactus-free-banner-partial.php';
            ?>
        </td>
        </tr>

      <tr valign="bottom">

        <td width="81" height="57">

          <!-- but act -->
          <!-- /but act -->
          <table border="0" cellpadding="0" cellspacing="0">
            <tr valign="bottom">
              <td width="10"><img src="images/b_left.gif" alt="left" width="10" height="30" border="0"></td>
              <td width="62" background="images/b_fon.gif"><p align="center" class="menu01"><a href="index.php">HOME</a></p></td>
              <td width="10"><img src="images/b_right.gif" width="9" height="30" alt="right" border="0"></td>
            </tr>
          </table></td>

        <td width="98">

          <!-- but -->

          <table width="98" border="0" cellpadding="0" cellspacing="0">

            <tr valign="bottom">

              <td width="10" height="30"><img src="images/b_left.gif" alt="" width="10" height="30" border="0"></td>

              <td width="78" background="images/b_fon.gif"><p class="menu01"><a href="aboutus.php">ABOUT US</a></p></td>

              <td width="10"><img src="images/b_right.gif" alt="" width="10" height="30" border="0"></td>
            </tr>
        </table></td>

        <td width="91">

          <!-- but -->

          <table border="0" cellpadding="0" cellspacing="0">

            <tr valign="bottom">

              <td width="10"><img src="images/b_left.gif" alt="" width="10" height="30" border="0"></td>

              <td width="71" background="images/b_fon.gif"><p class="menu01"><a href="courses.php">COURSES</a></p></td>

              <td width="10"><img src="images/b_right.gif" alt="" width="10" height="30" border="0"></td>
            </tr>
          </table>

          <!-- /but -->        </td>

        <td width="112">

          <!-- but -->

          <table width="112" border="0" cellpadding="0" cellspacing="0">

            <tr valign="bottom">

              <td width="10"><img src="images/b_left.gif" alt="" width="10" height="30" border="0"></td>

              <td width="92" background="images/b_fon.gif"><p class="menu01"> <a href="contactus.php">CONTACT US </a></p></td>

              <td width="10"><img src="images/b_right.gif" alt="" width="10" height="30" border="0"></td>
            </tr>
          </table>

          <!-- /but -->        </td>

        <td width="107"><table width="107" border="0" cellpadding="0" cellspacing="0">

            <tr valign="bottom">

              <td width="10"> <img src="images/b_left.gif" alt="" width="10" height="30" border="0"></td>

              <td width="87" background="images/b_fon.gif"><p class="menu01"><a href="university.php"> UNIVERSITY</a></p></td>

              <td width="99"><img src="images/b_right.gif" alt="" width="10" height="30" border="0"></td>
            </tr>

        </table></td>

        <td width="107"><table width="107" border="0" cellpadding="0" cellspacing="0">
          <tr valign="bottom">
            <td width="10"><img src="images/b_left.gif" alt="b_left" width="10" height="30" border="0"></td>
            <td width="87" background="images/b_fon.gif"><p class="menu01"><a href="invigilator.php"> INVIGILATOR</a></p></td>
            <td width="99"><img src="images/b_right.gif" alt="b_right" width="10" height="30" border="0"></td>
          </tr>
        </table></td>
      </tr>

    </table>	  </td>

</tr>

</table>

<table border="0" cellpadding="0" cellspacing="0" width="773" height="694">

<tr valign="top">

	<td width="183" height="565" bgcolor="#D0E0ED">

<table border="0" cellpadding="0" cellspacing="0" width="100%">

<tr>

	            <td bgcolor="#076BA7"> 

                  <table width="100%" border="0" cellspacing="0" cellpadding="0">

                    <tr>

                      <td><p>&nbsp;</p>

                      <p align="center" class="style3">&quot;Experienced<br>

                        and<br>

                        Dedicated&quot;</p>

                      <p>&nbsp;</p></td>
                    </tr>
                  </table>                </td>
</tr>

<form action="" method="post">
</form></table>

<div align="center"></div>

<div align="center"></div>

<div align="center"><br>
    <p align="left" class="style51"><span class="style63"><a href="umat.php" class="style11" style="text-decoration:none">UMAT Prep</a> </p>
  <div align="left">
      <p><strong><a href="umat.php"><img src="images/tick.jpg" border="0" alt="tick" width="16" height="17" longdesc="images/tick.jpg"></a></strong><a href="umat.php" class="unnamed1 style65"><span class="style65"> Logical<strong><br>
      </strong></span><img src="images/spacer.gif" alt="sp" width="19" height="18" border="0"><span class="style65">Reasoning</span></a></p>
    <p><a href="umat.php" class="unnamed1 style65"><strong><img src="images/tick.jpg" border="0" alt="tick" width="16" height="17" longdesc="images/tick.jpg"> </strong><span class="style65">Problem<strong><br>
      </strong></span><img src="images/spacer.gif" alt="sp" width="19" height="18" border="0"><span class="style65">Solving</span></a></p>
    <p><a href="umat.php" class="unnamed1 style65"><strong><img src="images/tick.jpg" border="0" alt="tick" width="16" height="17" longdesc="images/tick.jpg"> </strong>Understanding<img src="images/spacer.gif" alt="sp" width="19" height="18" border="0">People</a></p>
    <p><a href="umat.php" class="unnamed1 style65"><strong><img src="images/tick.jpg" border="0" alt="tick" width="16" height="17" longdesc="images/tick.jpg"></strong> Non-verbal<br>
            <img src="images/spacer.gif" alt="sp" width="19" height="18" border="0">Reasoning</a></p>
    <p><a href="umat.php" class="unnamed1 style65"><strong><img src="images/tick.jpg" border="0" alt="tick" width="16" height="17" longdesc="images/tick.jpg"></strong> Interview<br>
            <img src="images/spacer.gif" alt="sp" width="19" height="18" border="0">Training</a></p>
  </div>
  <nobr></nobr>
    <div align="center"><span class="style62">..........................</span><br>
    </div>
</div>
<p align="left" class="style51"><span class="style13">High School</span><span class="style11"> <br>
S</span><span class="style66">UBJECTS</span> </p>
<div align="left">
  <p><strong><img src="images/tick.jpg" border="0" alt="tick" width="16" height="17" longdesc="images/tick.jpg"></strong><a href="chemistry.php" class="unnamed1 style65"> Chemistry</a></p>
  <p><strong><a href="mathematics.php"><img src="images/tick.jpg" border="0" alt="tick" width="16" height="17" longdesc="images/tick.jpg"></a><a href="mathematics.php" class="unnamed1 style65"> Maths</a> </strong></p>
  <p><strong><a href="physics.php"><img src="images/tick.jpg" border="0" alt="tick" width="16" height="17" longdesc="images/tick.jpg"></a><a href="physics.php" class="unnamed1 style65"> Physics</a></strong></p>
  <p><strong><a href="biology.php"><img src="images/tick.jpg" border="0" alt="tick" width="16" height="17" longdesc="images/tick.jpg"></a><a href="biology.php" class="unnamed1 style65"> Biology </a></strong></p>
</div>
<div align="center"><span class="style62">..........................</span><br>
</div>
<p align="left" class="left"><span class="style51"><span class="style11"><span class="style13">Primary School</span> <br>
  S</span><span class="style66">UBJECTS</span></span></p>
<div align="left">
  <p><strong><img src="images/tick.jpg" border="0" alt="tick" width="16" height="17" longdesc="images/tick.jpg"></strong><strong><a href="primary.php" class="unnamed1 style65"> Maths</a></strong></p>
  <p><strong><a href="mathematics.php"><img src="images/tick.jpg" border="0" alt="tick" width="16" height="17" longdesc="images/tick.jpg"></a></strong><strong><a href="primary.php" class="unnamed1 style65"> English</a></strong></p>
  <p><strong><a href="physics.php"><img src="images/tick.jpg" border="0" alt="tick" width="16" height="17" longdesc="images/tick.jpg"></a> <a href="primary.php" class="unnamed1 style65"> General Ability</a></strong></p>
  <p><strong><a href="biology.php"><img src="images/tick.jpg" border="0" alt="tick" width="16" height="17" longdesc="images/tick.jpg"></a><a href="primary.php" class="unnamed1 style65"> Reading/Writing</a></strong></p>
</div>
<div align="left"></div>
<div align="center"><span class="style62">..........................</span><br>
</div>
<p align="center" class="left">&nbsp;</p>
<p align="center" class="left"><img src="images/e01.gif" width="14" height="16" alt="e01" border="0" align="absmiddle">&nbsp;&nbsp;WEB LINKS</p>
<p class="left">&nbsp;</p>
<p class="left">&nbsp;<a href="http://www.boardofstudies.nsw.edu.au" class="style2" rel="nofollow">NSW Board of Studies</a></p>
<p class="left">&nbsp;</p>
<p class="left"><a href="http://hsc.csu.edu.au" class="style2" rel="nofollow">NSW HSC Online </a></p>
<p class="left">&nbsp;</p>
<p class="left"><a href="http://www.uac.edu.au/" class="style2" rel="nofollow">University Admissions Centre </a></p>
<p class="left">&nbsp;</p>
<div align="center"><span class="style62">..........................</span><br>
</div>
<p class="left">&nbsp;</p>
<p align="center" class="style1">Einstein's Challenge </p>
<p align="center">Are you smarter than 98% of the world's population? </p>
<p align="center">Try this challenge to find out.</p>
<p align="center">
  <label>
  <input name="Button" type="button" onClick="MM_goToURL('parent','einstein.php');return document.MM_returnValue" value="Einstein's Challenge">
  </label>
  <br>
  <span class="style20">CLICK HERE</span></p>
<div align="center"><span class="style62">..........................</span><br>
</div>
<p align="center">&nbsp;</p>
<p align="center"><a href="index.php#testimonials" class="style30">
  <input name="Button2" type="button" class="style30" onClick="MM_goToURL('parent','testimonial.php');return document.MM_returnValue" value="'Testimonials'">
</a><strong>&quot;Proven Results</strong>&quot;</p>
<div align="center"><span class="style62">..........................</span><br>
</div>
<p align="center">&nbsp;</p>
<p align="center"><a href="index.php#testimonials" class="style30">
  <input name="Button22" type="button" class="style45" onClick="MM_goToURL('parent','ib.php');return document.MM_returnValue" value="IB EXAM PLUS">
</a><strong>International Baccalaureate Intense Exam Preperation</strong></p>
<p align="center"><strong>Higher level &amp; Standard Level Chemistry </strong></p>
<nobr></nobr>
<p align="center">&nbsp;</p></td>

	<td width="590" rowspan="2">

      <div align="left"><img src="images/top01.gif" width="600" height="24" alt="" border="0"></div>
      <table width="102%" height="647" border="0" cellpadding="0" cellspacing="0">

<tr>

  <td width="5%" height="186">&nbsp;</td>

	<td width="98%" colspan="2"><div align="center"> </div>

      <p style="color: #076BA7; font-size: 20px; margin-left: 0px;"><b></b><b>Einstein's Challenge </b></p>
	  <p class="style21">The great physicist Albert Einstein posed this puzzle and suggested that only 2% of the world's population could solve it. However, given enough time, more than the suggested 2% might possibly be able to find a solution to this question.</p>
	  <p class="style21">We here at Platinum Education Australia believe that everyone has the ability to solve such problems with ease, especially in the areas of mathematics, chemistry, physics and biology. Often things seem to become difficult because we do not have the training to solve the question that is starring  at us on the page. The secret is to develop  methods, a knowledge base and a way of thinking about Mathematics, Chemistry, Physics and Biology. Once students are taught these methods all questions will become much easier for them to solve, and so will help them to accomplish their desired exam results.<br>
	    <br>
	  </p>
	  <p align="center" class="style22">The Challenge 	    </p>
	  <p style="color: #000000; font-size: 16px; margin-left: 0px; font-style: italic;"><strong>Rules</strong></p>      
      <ol>
        <li class="style19">There are five houses in five different colors. </li>
        <li class="style19"> Each house is   owned by a man of a different nationality. </li>
        <li class="style19"> The five owners   drink a certain type of beverage, smoke a certain brand of cigar,   and keep a certain pet. </li>
        <li class="style19"> No owners have the same pet, smoke   the same brand of cigar, or drink the same beverage. </li>
        </ol>
		
		<span class="style17">Information</span>
      <ol>
        <li class="style19">The Brit lives in the red house. </li>
        <li class="style19">The Swede keeps dogs as pets. </li>
        <li class="style19">The Dane drinks tea. </li>
        <li class="style19">The green house is on the left of the white house. </li>
        <li class="style19">The green house's owner drinks coffee. </li>
        <li class="style19">The person who smokes Pall Mall rears birds. </li>
        <li class="style19">The owner of the yellow house smokes Dunhill. </li>
        <li class="style19">The man living in the center house drinks milk. </li>
        <li class="style19">The Norwegian lives in the first house. </li>
        <li class="style19">The man who smokes Blends lives next to the one who keeps cats. </li>
        <li class="style19">The man who keeps the horse lives next to the man who smokes Dunhill. </li>
        <li class="style19">The owner who smokes Bluemasters drinks beer. </li>
        <li class="style19">The German smokes Prince. </li>
        <li class="style19">The Norwegian lives next to the blue house. </li>
        <li class="style19">The man who smokes Blends has a neighbor who drinks water. </li>
        </ol>
      <p align="center" class="style7">&nbsp;</p>
      <p align="center" class="style7">Question: <strong>WHO OWN'S THE FISH?</strong></p>
      <p align="justify" class="style7"><span class="style11"><br>

      </span></p></td>
	</tr>
</table>

<div align="center"><img src="images/hr01.gif" width="556" height="11" alt="" border="0"></div>

    </td>

</tr>

<tr valign="bottom" bgcolor="#D0E0ED">

	<td height="83"><img src="images/bot_left.gif" width="183" height="21" alt="" border="0"></td>

</tr>

</table>

<table border="0" cellpadding="0" cellspacing="0" width="780" height="64" background="images/fon_bot.gif">

<tr valign="top">

	<td>

<table border="0" cellpadding="0" cellspacing="0" width="780" background="">

<tr>

	<td width="300"><p class="menu02">Copyright &copy; 2014 Platinum Education Australia</p></td>

	<td>

<p class="menu02">

<a href="home.html">Home</a>&nbsp;&nbsp;&nbsp;|&nbsp;&nbsp;&nbsp;

<a href="aboutus.php">About Us</a>&nbsp;&nbsp;&nbsp;|&nbsp;&nbsp;&nbsp;

<a href="courses.php">Courses</a>&nbsp;&nbsp;&nbsp;|&nbsp;&nbsp;&nbsp;

<a href="contactus.php">Contact Us</a>&nbsp;&nbsp;&nbsp;|&nbsp;&nbsp;&nbsp; <a href="university.php">University</a>&nbsp;&nbsp;&nbsp;|&nbsp;&nbsp;&nbsp;

<a href="invigilator.php"><strong>Invigilator</strong></a></p>	</td>

</tr>

</table>

	</td>

</tr>

</table>

<p align="center"></td>

	<td valign="bottom" background="images/bg_right.gif"><img src="images/bg_right.gif" alt="" width="17" height="16" border="0"></td>

	<td width="50%" background="images/bg.gif">&nbsp;</td>

</tr>

</table>

<img src="images/px1.gif" width="1" height="1" alt="" border="0">

<?php
    include 'partial/contactus-free-session-partial.php';
?>

<script type="application/javascript" src="js/jquery.min.js"></script>
<script type="application/javascript" src="js/bootstrap.js"></script>
<script type="text/javascript" src="js/bootstrapValidator.min.js"></script>
<script type="text/javascript" src="js/contactus-free-session.js"></script>

<!--WEBSITECEO:BEGIN:{764EEF2E-BC11-45CF-8627-300CE1BA2219}-->
<!--
Do NOT modify this script to avoid traffic misrepresentation! 
Web CEO 4 0300/1
Code initially inserted into: "//einstein.php".
-->
<script type="text/javascript"><!--
// hitlens v1.2.7
function hitlens_embedded() {
var id = 456727;
var pc = 7;
var PAGENAME = escape('');
var CONTENTGROUP = escape('');
var TRANSACTION = escape('');
var TRANSACTION_ID = 0;
var ORDER = escape('');
return "id="+id+"&pc="+pc+"&p="+PAGENAME+"&gr="+CONTENTGROUP+"&tr="+TRANSACTION+"&trid="+TRANSACTION_ID+"&ord="+ORDER;
}
//--></script>
<script type="text/javascript" src="webceo.js"></script>
<!--WEBSITECEO:END:{764EEF2E-BC11-45CF-8627-300CE1BA2219}-->


</body>

</html>