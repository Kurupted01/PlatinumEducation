<!DOCTYPE html>

<html>
<head> <link rel="icon" type="image/x-icon" href="images/Favicon.png"/>
    <title>Contact Us Tutoring | Platinum Education Australia | Sydney Tutoring</title>
    <meta name="description" CONTENT="Platinum Education Australia is located in Hornsby, which is in the upper northshore area of Sydney. We are the specialists in chemistry, maths, physics and biology tutoring" />
    <meta name="keywords" CONTENT="maths tutor, chemistry tutor, maths tutoring, chemistry tutoring, tutoring, tutors, maths, english, Sydney, local, Private, chemistry, biology, Coaching, Prices, physics, Home, Hsc, Excellence, home, IB, teaching, jobs, contact us, hornsby, north shore" />
    <meta name="robots" content="index, follow" />
    <link rel="stylesheet" type="text/css" href="css/bootstrap.css" />
    <link rel="stylesheet" type="text/css" href="style.css" />

    <link rel="stylesheet" type="text/css" href="css/customStyles.css" />
    <link rel="stylesheet" type="text/css" href="css/bootstrapValidator.min.css"/>

</head>

<body leftmargin=0 topmargin=0 marginheight="0" marginwidth="0" bgcolor="#ffffff">

<script language=JavaScript>
    <!--

    var message="";
    ///////////////////////////////////
    function clickIE() {if (document.all) {(message);return false;}}
    function clickNS(e) {if
        (document.layers||(document.getElementById&&!document.all)) {
        if (e.which==2||e.which==3) {(message);return false;}}}
    if (document.layers)
    {document.captureEvents(Event.MOUSEDOWN);document.onmousedown=clickNS;}
    else{document.onmouseup=clickNS;document.oncontextmenu=clickIE;}

    document.oncontextmenu=new Function("return false")
    // -->
</script>

<table border="0" cellspacing="0" cellpadding="0" width="100%" height="100%">
<tr valign="top">
<td width="50%" background="images/bg.gif"><img src="images/px1.gif" width="1" height="1" alt="" border="0"></td>
<td valign="bottom" background="images/bg_left.gif"><img src="images/bg_left.gif" alt="" width="17" height="16" border="0"></td>
<td>
    <!--<div id="bannerDiv"></div>-->

    <table border="0" cellpadding="0" cellspacing="0" width="780" height="107">
        <tr valign="bottom">
            <td width="800" background="images/fon_top.gif">	  <table width="755" height="224" border="0" cellpadding="0" cellspacing="0" background="">
                    <tr valign="bottom">
                        <td width="226" rowspan="2"><img src="images/platedimage6.gif" width="181" height="219"> </td>
                        <td height="163" colspan="6">
                            <?php
                                include 'partial/contactus-free-banner-partial.php';
                            ?>
                        </td>
                    </tr>
                    <tr valign="bottom">
                        <td width="70" height="57"><table border="0" cellpadding="0" cellspacing="0">
                                <tr valign="bottom">
                                    <td><img src="images/b_left.gif" width="9" height="30" alt="" border="0"></td>
                                    <td background="images/b_fon.gif"><p class="menu01"><a href="index.php">HOME</a></p></td>
                                    <td><img src="images/b_right.gif" width="9" height="30" alt="" border="0"></td>
                                </tr>
                            </table>
                            <!-- but act -->
                            <!-- /but act --></td>
                        <td width="98"><table width="98" border="0" cellpadding="0" cellspacing="0">
                                <tr valign="bottom">
                                    <td width="10"><img src="images/b_left.gif" alt="" width="10" height="30" border="0"></td>
                                    <td width="78" background="images/b_fon.gif"><p class="menu01"><a href="aboutus.php">ABOUT US</a></p></td>
                                    <td width="10"><img src="images/b_right.gif" alt="" width="10" height="30" border="0"></td>
                                </tr>
                            </table>            <!-- but -->          </td>
                        <td width="92"><table width="92" border="0" cellpadding="0" cellspacing="0">
                                <tr valign="bottom">
                                    <td width="10"><img src="images/b_left.gif" alt="" width="10" height="30" border="0"></td>
                                    <td width="72" background="images/b_fon.gif"><p class="menu01"><a href="courses.php">COURSES</a></p></td>
                                    <td width="10"><img src="images/b_right.gif" alt="" width="10" height="30" border="0"></td>
                                </tr>
                            </table>
                            <!-- but -->
                            <!-- /but --></td>
                        <td width="137"><table width="137" border="0" cellpadding="0" cellspacing="0">
                                <tr valign="bottom">
                                    <td width="10"><img src="images/b_left_a.gif" alt="" width="10" height="37" border="0"></td>
                                    <td width="117" background="images/b_fon_a.gif"><p class="menu01"><a href="contactus.php" class="style1"> CONTACT US </a></p></td>
                                    <td width="10"><img src="images/b_right_a.gif" alt="" width="10" height="37" border="0"></td>
                                </tr>
                            </table>
                            <!-- but -->
                            <!-- /but --></td>
                        <td width="108"><table width="107" border="0" cellpadding="0" cellspacing="0">
                                <tr valign="bottom">
                                    <td width="10"> <img src="images/b_left.gif" alt="" width="10" height="30" border="0"></td>
                                    <td width="87" background="images/b_fon.gif"><p class="menu01"><a href="university.php"> UNIVERSITY</a></p></td>
                                    <td width="99"><img src="images/b_right.gif" alt="" width="10" height="30" border="0"></td>
                                </tr>
                            </table></td>
                        <td width="108"><table width="107" border="0" cellpadding="0" cellspacing="0">
                                <tr valign="bottom">
                                    <td width="10"><img src="images/b_left.gif" alt="b_left" width="10" height="30" border="0"></td>
                                    <td width="87" background="images/b_fon.gif"><p class="menu01"><a href="invigilator.php"> INVIGILATOR</a></p></td>
                                    <td width="99"><img src="images/b_right.gif" alt="b_right" width="10" height="30" border="0"></td>
                                </tr>
                            </table></td>
                    </tr>
                </table></td>
        </tr>
    </table>
    <table border="0" cellpadding="0" cellspacing="0" width="780" height="1084">
<tr valign="top">
<td bgcolor="#D0E0ED">
    <table border="0" cellpadding="0" cellspacing="0" width="100%">
        <tr>
            <td bgcolor="#076BA7">
                <table width="100%" border="0" cellspacing="0" cellpadding="0">
                    <tr>
                        <td><p>&nbsp;</p>
                            <p align="center"><span class="style3">&quot;Experienced<br>
and<br>
Dedicated&quot;</span></p>
                            <p>&nbsp;</p></td>
                    </tr>
                </table>

            </td>
        </tr>
    </table>
    <div align="center"></div>
    <div align="center"></div>
    <nobr></nobr>
    <div align="center">
        <span>&nbsp;</span>
    </div>
    <div align="center">
        <div align="center"><br>
            <p align="left" class="style16"><span class="style63"><a href="umat.php" class="style63" style="text-decoration:none">UMAT Prep</a> </p>
            <div align="left">
                <p><strong><a href="umat.php"><img src="images/tick.jpg" border="0" alt="tick" width="16" height="17" longdesc="images/tick.jpg"></a></strong><a href="umat.php" class="unnamed1 style65"><span class="style65"> Logical<strong><br>
                            </strong></span><img src="images/spacer.gif" alt="sp" width="19" height="18" border="0"><span class="style65">Reasoning</span></a></p>
                <p><a href="umat.php" class="unnamed1 style65"><strong><img src="images/tick.jpg" border="0" alt="tick" width="16" height="17" longdesc="images/tick.jpg"> </strong><span class="style65">Problem<strong><br>
                            </strong></span><img src="images/spacer.gif" alt="sp" width="19" height="18" border="0"><span class="style65">Solving</span></a></p>
                <p><a href="umat.php" class="unnamed1 style65"><strong><img src="images/tick.jpg" border="0" alt="tick" width="16" height="17" longdesc="images/tick.jpg"> </strong>Understanding<img src="images/spacer.gif" alt="sp" width="19" height="18" border="0">People</a></p>
                <p><a href="umat.php" class="unnamed1 style65"><strong><img src="images/tick.jpg" border="0" alt="tick" width="16" height="17" longdesc="images/tick.jpg"></strong> Non-verbal<br>
                        <img src="images/spacer.gif" alt="sp" width="19" height="18" border="0">Reasoning</a></p>
                <p><a href="umat.php" class="unnamed1 style65"><strong><img src="images/tick.jpg" border="0" alt="tick" width="16" height="17" longdesc="images/tick.jpg"></strong> Interview<br>
                        <img src="images/spacer.gif" alt="sp" width="19" height="18" border="0">Training</a></p>
            </div>
            <nobr></nobr>
            <div align="center"><span class="style62">..........................</span><br>
            </div>
        </div>
        <p align="left" class="style16"><span class="style13">High School</span><span class="style63"> <br>
S</span><span class="style1">UBJECTS</span> </p>
        <div align="left">
            <p><strong><img src="images/tick.jpg" border="0" alt="tick" width="16" height="17" longdesc="images/tick.jpg"></strong><a href="chemistry.php" class="unnamed1 style65"> Chemistry</a></p>
            <p><strong><a href="mathematics.php"><img src="images/tick.jpg" border="0" alt="tick" width="16" height="17" longdesc="images/tick.jpg"></a><a href="mathematics.php" class="unnamed1 style65"> Maths</a> </strong></p>
            <p><strong><a href="physics.php"><img src="images/tick.jpg" border="0" alt="tick" width="16" height="17" longdesc="images/tick.jpg"></a><a href="physics.php" class="unnamed1 style65"> Physics</a></strong></p>
            <p><strong><a href="biology.php"><img src="images/tick.jpg" border="0" alt="tick" width="16" height="17" longdesc="images/tick.jpg"></a><a href="biology.php" class="unnamed1 style65"> Biology </a></strong></p>
        </div>
        <div align="center"><span class="style62">..........................</span><br>
        </div>
        <p align="left" class="left"><span class="style16"><span class="style63"><span class="style13">Primary School</span> <br>
  S</span><span class="style1">UBJECTS</span></span></p>
        <div align="left">
            <p><strong><img src="images/tick.jpg" border="0" alt="tick" width="16" height="17" longdesc="images/tick.jpg"></strong><strong><a href="primary.php" class="unnamed1 style65"> Maths</a></strong></p>
            <p><strong><a href="mathematics.php"><img src="images/tick.jpg" border="0" alt="tick" width="16" height="17" longdesc="images/tick.jpg"></a></strong><strong><a href="primary.php" class="unnamed1 style65"> English</a></strong></p>
            <p><strong><a href="physics.php"><img src="images/tick.jpg" border="0" alt="tick" width="16" height="17" longdesc="images/tick.jpg"></a> <a href="primary.php" class="unnamed1 style65"> General Ability</a></strong></p>
            <p><strong><a href="biology.php"><img src="images/tick.jpg" border="0" alt="tick" width="16" height="17" longdesc="images/tick.jpg"></a><a href="primary.php" class="unnamed1 style65"> Reading/Writing</a></strong></p>
        </div>
        <div align="left"></div>
        <div align="center"><span class="style62">..........................</span><br>
        </div>
        <p align="center" class="left">&nbsp;</p>
        <p align="center" class="left"><img src="images/e01.gif" width="14" height="16" alt="e01" border="0" align="absmiddle">&nbsp;&nbsp;WEB LINKS</p>
        <p class="left">&nbsp;</p>
        <p class="left">&nbsp;<a href="http://www.boardofstudies.nsw.edu.au" class="style2" rel="nofollow">NSW Board of Studies</a></p>
        <p class="left">&nbsp;</p>
        <p class="left"><a href="http://hsc.csu.edu.au" class="style2" rel="nofollow">NSW HSC Online </a></p>
        <p class="left">&nbsp;</p>
        <p class="left"><a href="http://www.uac.edu.au/" class="style2" rel="nofollow">University Admissions Centre </a></p>
        <p class="left">&nbsp;</p>
        <div align="center"><span class="style62">..........................</span><br>
        </div>
        <p class="left">&nbsp;</p>
        <p align="center" class="style21">Einstein's Challenge </p>
        <p align="center">Are you smarter than 98% of the world's population? </p>
        <p align="center">Try this challenge to find out.</p>
        <p align="center">
            <label>
                <input name="Button" type="button" onClick="MM_goToURL('parent','einstein.php');return document.MM_returnValue" value="Einstein's Challenge">
            </label>
            <br>
            <span class="style20">CLICK HERE</span></p>
        <div align="center"><span class="style62">..........................</span><br>
        </div>
        <p align="center">&nbsp;</p>
        <p align="center"><a href="index.php#testimonials" class="style29">
                <input name="Button2" type="button" class="style29" onClick="MM_goToURL('parent','testimonial.php');return document.MM_returnValue" value="'Testimonials'">
            </a><strong>&quot;Proven Results</strong>&quot;</p>
        <div align="center"><span class="style62">..........................</span><br>
        </div>
        <p align="center">&nbsp;</p>
        <p align="center"><a href="index.php#testimonials" class="style29">
                <input name="Button22" type="button" class="style45" onClick="MM_goToURL('parent','ib.php');return document.MM_returnValue" value="IB EXAM PLUS">
            </a><strong>International Baccalaureate Intense Exam Preperation</strong></p>
        <p align="center"><strong>Higher level &amp; Standard Level Chemistry </strong></p>
        <p align="center"></p>
        <div align="center">
            <p><br>
                <br>
            </p>
</td>
<td rowspan="2">
<div align="left"><img src="images/top01.gif" width="611" height="24" alt="" border="0"></div>
<table border="0" cellpadding="0" cellspacing="0" width="100%">
<tr>
    <td>&nbsp;</td>
    <td colspan="2" align="left"><p style="color: #076BA7; font-size: 20px; margin-left: 0px;"><b>Contact Us </b></p>
        <p align="justify" class="style1">The best way to contact Platinum Education Australia is to call and speak with the Head Tutor, or click the 'Contact Us' button below and fill in the form with your contact details and someone will be in touch with you within 24 hours.</p>
        <p align="justify">
            <!-- Button trigger modal -->
            <button class="btn btn-primary btn-lg" data-toggle="modal" data-target="#contactUsModal">
                Contact Us
            </button>
        </p>
        <p align="justify" class="style1">Platinum Education Australia is located in Hornsby, which is in the upper northshore area of Sydney.</p></td>
</tr>
<tr>
    <td>&nbsp;</td>
    <td width="45%" align="left"><p align="left" class="style1"><strong>Head Office</strong> <br>
            <br>
            Hornsby NSW 2077<br>
            Telephone: (02) 9045 1300<br>
            Fascimile: (02) 8212 5929 <br>
        </p>
        <p align="left" class="style1"><strong>Email:</strong> <a href="mailto:info@platinumeducation.com.au" class="style15">info@platinumeducation.com.au</a><br>
        </p>
        <p align="left" class="style1"><strong>Website: </strong><a href="http://www.platinumeducation.com.au" class="style15">www.platinumeducation.com.au</a></p></td>
    <td width="53%" align="left"><div align="center"><iframe width="300" height="300" frameborder="0" scrolling="no" marginheight="0" marginwidth="0" src="http://maps.google.com.au/maps/ms?hl=en&amp;ie=UTF8&amp;msa=0&amp;msid=208191792653555104118.00049888a9f8672f31de6&amp;ll=-33.70376,151.098726&amp;spn=0.005355,0.006437&amp;z=16&amp;output=embed"></iframe><br />
        </div></td>
</tr>
<tr>
<td width="2%">&nbsp;</td>

<td colspan="2" align="left">

<form action="" method="post" >
<input name="action" type="hidden" value="send">

</form>   </td>
</tr>
</table>
<div align="center"><img src="images/hr01.gif" width="556" height="11" alt="" border="0"></div>
</td>
</tr>
<tr valign="bottom" bgcolor="#D0E0ED">
    <td height="714"><img src="images/bot_left.gif" width="183" height="21" alt="" border="0"></td>
</tr>
</table>
<table border="0" cellpadding="0" cellspacing="0" width="780" height="64" background="images/fon_bot.gif">
    <tr valign="top">
        <td>
            <table border="0" cellpadding="0" cellspacing="0" width="780" background="">
                <tr>
                    <td width="300"><p class="menu02">Copyright &copy; 2014 Platinum Education Australia | Sydney |</p></td>
                    <td>
                        <p class="menu02">
                            <a href="index.php">Home</a>&nbsp;&nbsp;&nbsp;|&nbsp;&nbsp;&nbsp;
                            <a href="aboutus.php">About Us</a>&nbsp;&nbsp;&nbsp;|&nbsp;&nbsp;&nbsp;
                            <a href="courses.php">Courses</a>&nbsp;&nbsp;&nbsp;|&nbsp;&nbsp;&nbsp; <a href="contactus.php">Contact Us </a>&nbsp;&nbsp;&nbsp;|&nbsp;&nbsp;&nbsp; <a href="university.php">University</a>&nbsp;&nbsp;&nbsp;| <a href="invigilator.php"><strong>Invigilator</strong></a></p>	</td>
                </tr>
            </table>
        </td>
    </tr>
</table>
<p align="center"></td>
<td valign="bottom" background="images/bg_right.gif"><img src="images/bg_right.gif" alt="" width="17" height="16" border="0"></td>
<td width="50%" background="images/bg.gif"><img src="images/px1.gif" width="1" height="1" alt="" border="0"></td>
</tr>
</table>

<?php
include 'partial/contactus-free-session-partial.php';
include 'partial/contactus-partial.php';
?>

<script type="application/javascript" src="js/jquery.min.js"></script>
<script type="application/javascript" src="js/bootstrap.js"></script>
<script type="application/javascript" src="js/contactus-common.js"></script>
<script type="text/javascript" src="js/bootstrapValidator.min.js"></script>
<script type="text/javascript" src="js/contactus-free-session.js"></script>

<!--WEBSITECEO:BEGIN:{764EEF2E-BC11-45CF-8627-300CE1BA2219}-->
<!--
Do NOT modify this script to avoid traffic misrepresentation!
Web CEO 4 0300/1
Code initially inserted into: "/contactus.php".
-->
<script type="text/javascript"><!--
    // hitlens v1.2.7
    function hitlens_embedded() {
        var id = 456727;
        var pc = 5;
        var PAGENAME = escape('');
        var CONTENTGROUP = escape('');
        var TRANSACTION = escape('');
        var TRANSACTION_ID = 0;
        var ORDER = escape('');
        return "id="+id+"&pc="+pc+"&p="+PAGENAME+"&gr="+CONTENTGROUP+"&tr="+TRANSACTION+"&trid="+TRANSACTION_ID+"&ord="+ORDER;
    }
    //--></script>
<script type="text/javascript" src="webceo.js"></script>
<!--WEBSITECEO:END:{764EEF2E-BC11-45CF-8627-300CE1BA2219}-->


</body>
</html>
