<table border="0" cellpadding="0" cellspacing="0" width="780" height="107">
    <tr valign="bottom">
        <td width="800" background="images/fon_top.gif">	  <table width="755" height="224" border="0" cellpadding="0" cellspacing="0" background="">
            <tr valign="bottom">
                <td width="226" rowspan="2"><img src="images/platedimage6.gif" width="181" height="219"> </td>
                <td height="163" colspan="6">
                    <div id="parentContainer">
                        <img src="images/header.gif" class="main_image" width="489" height="163" />
                        <a href="#" data-toggle="modal" data-target="#contactUsFreeModal"><img src="images/SpecialOffer.png" class="overlay_image" /></a>
                    </div>
                </td>
            </tr>
            <tr valign="bottom">
                <td width="70" height="57"><table border="0" cellpadding="0" cellspacing="0">
                    <tr valign="bottom">
                        <td><img src="images/b_left.gif" width="9" height="30" alt="" border="0"></td>
                        <td background="images/b_fon.gif"><p class="menu01"><a href="index.php">HOME</a></p></td>
                        <td><img src="images/b_right.gif" width="9" height="30" alt="" border="0"></td>
                    </tr>
                </table>
                    <!-- but act -->
                    <!-- /but act --></td>
                <td width="98"><table width="98" border="0" cellpadding="0" cellspacing="0">
                    <tr valign="bottom">
                        <td width="10"><img src="images/b_left.gif" alt="" width="10" height="30" border="0"></td>
                        <td width="78" background="images/b_fon.gif"><p class="menu01"><a href="aboutus.php">ABOUT US</a></p></td>
                        <td width="10"><img src="images/b_right.gif" alt="" width="10" height="30" border="0"></td>
                    </tr>
                </table>            <!-- but -->          </td>
                <td width="92"><table width="92" border="0" cellpadding="0" cellspacing="0">
                    <tr valign="bottom">
                        <td width="10"><img src="images/b_left.gif" alt="" width="10" height="30" border="0"></td>
                        <td width="72" background="images/b_fon.gif"><p class="menu01"><a href="courses.php">COURSES</a></p></td>
                        <td width="10"><img src="images/b_right.gif" alt="" width="10" height="30" border="0"></td>
                    </tr>
                </table>
                    <!-- but -->
                    <!-- /but --></td>
                <td width="137"><table width="137" border="0" cellpadding="0" cellspacing="0">
                    <tr valign="bottom">
                        <td width="10"><img src="images/b_left_a.gif" alt="" width="10" height="37" border="0"></td>
                        <td width="117" background="images/b_fon_a.gif"><p class="menu01"><a href="contactus.php" class="style1"> CONTACT US </a></p></td>
                        <td width="10"><img src="images/b_right_a.gif" alt="" width="10" height="37" border="0"></td>
                    </tr>
                </table>
                    <!-- but -->
                    <!-- /but --></td>
                <td width="108"><table width="107" border="0" cellpadding="0" cellspacing="0">
                    <tr valign="bottom">
                        <td width="10"> <img src="images/b_left.gif" alt="" width="10" height="30" border="0"></td>
                        <td width="87" background="images/b_fon.gif"><p class="menu01"><a href="university.php"> UNIVERSITY</a></p></td>
                        <td width="99"><img src="images/b_right.gif" alt="" width="10" height="30" border="0"></td>
                    </tr>
                </table></td>
                <td width="108"><table width="107" border="0" cellpadding="0" cellspacing="0">
                    <tr valign="bottom">
                        <td width="10"><img src="images/b_left.gif" alt="b_left" width="10" height="30" border="0"></td>
                        <td width="87" background="images/b_fon.gif"><p class="menu01"><a href="invigilator.php"> INVIGILATOR</a></p></td>
                        <td width="99"><img src="images/b_right.gif" alt="b_right" width="10" height="30" border="0"></td>
                    </tr>
                </table></td>
            </tr>
        </table></td>
    </tr>
</table>