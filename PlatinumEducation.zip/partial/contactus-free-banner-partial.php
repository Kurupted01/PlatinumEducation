<div id="parentContainer">
    <img src="images/header.gif" class="main_image" width="489" height="163" />
    <a href="#" data-toggle="modal" data-target="#contactUsFreeModal"><img src="images/SpecialOffer.png" class="overlay_image" /></a>
</div>