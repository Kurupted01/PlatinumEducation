<?php
/**
 * Created by PhpStorm.
 * User: andrews
 * Date: 8/22/14
 * Time: 3:52 PM
 */
date_default_timezone_set("Australia/Sydney");
phpinfo();