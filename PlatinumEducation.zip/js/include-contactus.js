'use strict';

$(function(){
    $("#contactUsDiv").load("partial/contactus-partial.html");
});