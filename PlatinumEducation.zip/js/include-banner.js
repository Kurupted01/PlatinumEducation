'use strict';

$(function(){
    $("#bannerDiv").load("partial/banner-partial.html");
});